import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  AlertTriangle,
  Bot,
  CheckCircle,
  Circle,
  Lightbulb,
  Wand2,
  TrendingUp,
  Loader2
} from "lucide-react";
import type { Exercise } from "@shared/schema";

interface RightPanelProps {
  activeTab: "output" | "hints" | "tests" | "debug";
  onTabChange: (tab: "output" | "hints" | "tests" | "debug") => void;
  executionResult?: any;
  currentExercise?: Exercise;
  isExecuting: boolean;
}

export default function RightPanel({
  activeTab,
  onTabChange,
  executionResult,
  currentExercise,
  isExecuting,
}: RightPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [hints, setHints] = useState<string[]>([]);
  const [isLoadingHint, setIsLoadingHint] = useState(false);

  const hintMutation = useMutation({
    mutationFn: async (data: { code: string; exerciseId: string; previousHints: string[] }) => {
      const response = await apiRequest("POST", "/api/hints/generate", data);
      return await response.json();
    },
    onSuccess: (data) => {
      setHints(prev => [...prev, data.hint]);
      setIsLoadingHint(false);
    },
    onError: (error) => {
      setIsLoadingHint(false);
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate hint. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGetHint = () => {
    if (!currentExercise) return;
    
    setIsLoadingHint(true);
    hintMutation.mutate({
      code: "", // This would come from the editor
      exerciseId: currentExercise.id,
      previousHints: hints,
    });
  };

  const tabs = [
    { id: "output", label: "Output", active: activeTab === "output" },
    { id: "hints", label: "Hints", active: activeTab === "hints" },
    { id: "tests", label: "Tests", active: activeTab === "tests" },
    { id: "debug", label: "Debug", active: activeTab === "debug" },
  ] as const;

  const renderOutputPanel = () => {
    if (isExecuting) {
      return (
        <div className="flex items-center justify-center py-8">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Executing code...</p>
          </div>
        </div>
      );
    }

    if (!executionResult) {
      return (
        <div className="text-center py-8">
          <Circle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Click "Run Code" to see output</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {/* Error Detection */}
        {executionResult.execution?.errors?.length > 0 && (
          <Card className="border-red-200 bg-red-50 dark:bg-red-900/20">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-red-800 dark:text-red-200">
                    Execution Error
                  </h4>
                  <p className="text-sm text-red-700 dark:text-red-300 mt-1">
                    {executionResult.execution.errors[0]}
                  </p>
                  <div className="mt-3 space-x-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-xs bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-900 dark:text-red-200 dark:hover:bg-red-800"
                      onClick={handleGetHint}
                      disabled={isLoadingHint}
                      data-testid="button-get-hint"
                    >
                      <Lightbulb className="w-3 h-3 mr-1" />
                      Get Hint
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-xs bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-900 dark:text-red-200 dark:hover:bg-red-800"
                      data-testid="button-suggest-fix"
                    >
                      <Wand2 className="w-3 h-3 mr-1" />
                      Suggest Fix
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* AI Analysis */}
        {executionResult.analysis && (
          <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <Bot className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    AI Analysis
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                    {executionResult.analysis.suggestions?.[0]?.message || 
                     "Your code structure looks good. Consider adding error handling for edge cases."}
                  </p>
                  {executionResult.analysis.suggestions?.[0]?.code && (
                    <div className="mt-3 bg-blue-100 dark:bg-blue-900 rounded p-2 font-mono text-xs">
                      {executionResult.analysis.suggestions[0].code}
                    </div>
                  )}
                  <div className="mt-3 space-x-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-xs bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-200 dark:hover:bg-blue-800"
                      data-testid="button-apply-suggestion"
                    >
                      Apply Suggestion
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-200"
                      data-testid="button-learn-more"
                    >
                      Learn More
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Console Output */}
        <Card>
          <CardContent className="p-4">
            <h4 className="text-sm font-medium mb-2">Console Output</h4>
            <div className="bg-background rounded p-3 font-mono text-sm border">
              {isExecuting ? (
                <div className="text-muted-foreground">Running code...</div>
              ) : executionResult.execution?.output ? (
                <div className="whitespace-pre-wrap" data-testid="console-output">
                  {executionResult.execution.output}
                </div>
              ) : executionResult.execution?.errors?.length > 0 ? (
                <div className="text-red-600 dark:text-red-400 whitespace-pre-wrap">
                  {executionResult.execution.errors.join('\n')}
                </div>
              ) : (
                <div className="text-muted-foreground">No output</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Test Results */}
        {executionResult.execution?.testResults && (
          <Card>
            <CardContent className="p-4">
              <h4 className="text-sm font-medium mb-2">Test Results</h4>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Passed: {executionResult.execution.testResults.passed}</span>
                  <span>Failed: {executionResult.execution.testResults.failed}</span>
                </div>
                <div className="space-y-1">
                  {executionResult.execution.testResults.details?.map((test: any, index: number) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      {test.passed ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <Circle className="w-4 h-4 text-red-500" />
                      )}
                      <span className={test.passed ? "text-green-700 dark:text-green-400" : "text-red-700 dark:text-red-400"}>
                        {test.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Learning Progress */}
        <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <h4 className="text-sm font-medium text-green-800 dark:text-green-200">
                Learning Progress
              </h4>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-green-700 dark:text-green-300">Function Definition</span>
                <span className="text-green-600 dark:text-green-400">✓ Mastered</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-green-700 dark:text-green-300">Parameter Handling</span>
                <span className="text-amber-600 dark:text-amber-400">⚡ Practicing</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-green-700 dark:text-green-300">Error Debugging</span>
                <span className="text-gray-500 dark:text-gray-400">○ Not Started</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderHintsPanel = () => (
    <div className="space-y-4">
      {hints.length === 0 ? (
        <div className="text-center py-8">
          <Lightbulb className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground mb-4">
            Need help? Get personalized hints for this exercise.
          </p>
          <Button 
            onClick={handleGetHint}
            disabled={isLoadingHint || !currentExercise}
            data-testid="button-request-hint"
          >
            {isLoadingHint ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Lightbulb className="w-4 h-4 mr-2" />
            )}
            Get First Hint
          </Button>
        </div>
      ) : (
        <>
          {hints.map((hint, index) => (
            <Card key={index} className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-blue-800 dark:text-blue-200">{hint}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          <div className="text-center">
            <Button 
              variant="outline"
              onClick={handleGetHint}
              disabled={isLoadingHint}
              data-testid="button-next-hint"
            >
              {isLoadingHint ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Lightbulb className="w-4 h-4 mr-2" />
              )}
              Get Next Hint
            </Button>
          </div>
        </>
      )}
    </div>
  );

  const renderTestsPanel = () => (
    <div className="space-y-4">
      <h4 className="text-sm font-medium">Test Cases</h4>
      {currentExercise?.testCases ? (
        <div className="space-y-2">
          {(currentExercise.testCases as any[]).map((test, index) => (
            <Card key={index}>
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Test {index + 1}</span>
                  <Badge variant="outline">Pending</Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  <div>Input: {JSON.stringify(test.input)}</div>
                  <div>Expected: {JSON.stringify(test.expected)}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-muted-foreground text-sm">
          No test cases available for this exercise.
        </div>
      )}
    </div>
  );

  const renderDebugPanel = () => (
    <div className="space-y-4">
      <h4 className="text-sm font-medium">Debug Tools</h4>
      <Card>
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground mb-3">
            Debug tools will be available when code execution encounters errors.
          </p>
          <div className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start" disabled>
              <Circle className="w-4 h-4 mr-2" />
              Set Breakpoint
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start" disabled>
              <Circle className="w-4 h-4 mr-2" />
              Step Through Code
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start" disabled>
              <Circle className="w-4 h-4 mr-2" />
              Inspect Variables
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <aside className="w-96 bg-card border-l border-border flex flex-col" data-testid="right-panel">
      {/* Panel Tabs */}
      <div className="h-12 border-b border-border flex">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex-1 text-sm font-medium transition-colors ${
              tab.active
                ? "bg-accent text-accent-foreground border-b-2 border-primary"
                : "hover:bg-muted text-muted-foreground"
            }`}
            data-testid={`tab-${tab.id}`}
          >
            {tab.label}
          </button>
        ))}
      </div>
      
      {/* Panel Content */}
      <div className="flex-1 p-4 overflow-y-auto">
        {activeTab === "output" && renderOutputPanel()}
        {activeTab === "hints" && renderHintsPanel()}
        {activeTab === "tests" && renderTestsPanel()}
        {activeTab === "debug" && renderDebugPanel()}
      </div>
    </aside>
  );
}
