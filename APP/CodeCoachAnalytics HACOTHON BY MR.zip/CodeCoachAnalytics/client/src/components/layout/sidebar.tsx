import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { 
  BookOpen, 
  Clock, 
  Check, 
  Lock, 
  PlayCircle,
  Target
} from "lucide-react";
import type { Course, Lesson, Exercise } from "@shared/schema";

interface SidebarProps {
  course?: Course;
  lessons: Lesson[];
  exercises: Exercise[];
  currentExerciseId: string;
  onExerciseSelect: (exerciseId: string) => void;
}

export default function Sidebar({
  course,
  lessons,
  exercises,
  currentExerciseId,
  onExerciseSelect,
}: SidebarProps) {
  // Mock progress data - in real app, this would come from user progress
  const mockProgress = {
    completedLessons: 2,
    totalLessons: lessons.length || 4,
    timeSpent: 4.5,
    progressPercentage: 67,
  };

  const getExerciseStatus = (exercise: Exercise, index: number) => {
    if (exercise.id === currentExerciseId) return "current";
    if (index < 2) return "completed"; // Mock: first 2 exercises completed
    if (index === 2) return "in_progress"; // Mock: 3rd exercise in progress
    return "locked"; // Mock: remaining exercises locked
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <Check className="w-4 h-4 text-primary-foreground" />;
      case "current":
      case "in_progress":
        return <span className="text-white text-xs font-bold">3</span>;
      case "locked":
        return <Lock className="w-4 h-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-primary";
      case "current":
      case "in_progress":
        return "bg-amber-500";
      case "locked":
        return "border-2 border-muted-foreground";
      default:
        return "bg-muted";
    }
  };

  return (
    <aside className="w-80 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Course Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-foreground" data-testid="text-course-title">
            {course?.title || "Python Fundamentals"}
          </h2>
          <Badge variant="secondary" data-testid="badge-difficulty">
            {course?.difficulty || "Beginner"}
          </Badge>
        </div>
        
        {/* Progress Overview */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium" data-testid="text-progress-percentage">
              {mockProgress.progressPercentage}%
            </span>
          </div>
          <Progress value={mockProgress.progressPercentage} className="h-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span data-testid="text-lessons-completed">
              {mockProgress.completedLessons} of {mockProgress.totalLessons} lessons
            </span>
            <span data-testid="text-time-spent">
              {mockProgress.timeSpent} hours
            </span>
          </div>
        </div>
      </div>
      
      {/* Lesson Navigation */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-2">
          {exercises.length > 0 ? exercises.map((exercise, index) => {
            const status = getExerciseStatus(exercise, index);
            const isActive = exercise.id === currentExerciseId;
            const isClickable = status !== "locked";
            
            return (
              <div
                key={exercise.id}
                className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-colors ${
                  isActive 
                    ? "bg-accent border-l-4 border-primary" 
                    : isClickable
                    ? "hover:bg-muted" 
                    : "opacity-60 cursor-not-allowed"
                }`}
                onClick={() => isClickable && onExerciseSelect(exercise.id)}
                data-testid={`exercise-item-${exercise.id}`}
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${getStatusColor(status)}`}>
                  {getStatusIcon(status)}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${
                    status === "locked" ? "text-muted-foreground" : "text-foreground"
                  }`}>
                    {exercise.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {exercise.difficulty} • {exercise.estimatedMinutes || 30} min
                  </p>
                </div>
                {isActive && (
                  <div className="w-2 h-2 bg-primary rounded-full" data-testid="current-exercise-indicator"></div>
                )}
              </div>
            );
          }) : (
            // Fallback mock lessons for when no exercises are loaded
            <>
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-secondary cursor-pointer">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <Check className="text-primary-foreground text-xs" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Variables & Data Types</p>
                  <p className="text-xs text-muted-foreground">5 exercises • 45 min</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted cursor-pointer">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <Check className="text-primary-foreground text-xs" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Control Structures</p>
                  <p className="text-xs text-muted-foreground">7 exercises • 60 min</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-accent border-l-4 border-primary cursor-pointer">
                <div className="w-6 h-6 bg-amber-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">3</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Functions & Scope</p>
                  <p className="text-xs text-muted-foreground">4 exercises • 50 min</p>
                </div>
                <div className="w-2 h-2 bg-primary rounded-full"></div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted cursor-pointer opacity-60">
                <div className="w-6 h-6 border-2 border-muted-foreground rounded-full flex items-center justify-center">
                  <Lock className="text-muted-foreground text-xs" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">Object-Oriented Programming</p>
                  <p className="text-xs text-muted-foreground">6 exercises • 90 min</p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      
      {/* Current Exercise Info */}
      <div className="p-4 border-t border-border">
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center space-x-2 mb-2">
              <PlayCircle className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium" data-testid="text-current-exercise">
                Current: Exercise {exercises.findIndex(e => e.id === currentExerciseId) + 1 || 3}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mb-2" data-testid="text-exercise-description">
              {exercises.find(e => e.id === currentExerciseId)?.description || 
               "Create a function that calculates compound interest"}
            </p>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">
                Difficulty: {exercises.find(e => e.id === currentExerciseId)?.difficulty || "Medium"}
              </span>
              <Badge variant="secondary" className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                In Progress
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}
