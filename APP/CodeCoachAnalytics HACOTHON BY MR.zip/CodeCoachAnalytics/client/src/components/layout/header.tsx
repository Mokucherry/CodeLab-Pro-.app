import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Code, Search, Bell, User, Settings, LogOut } from "lucide-react";
import { Link } from "wouter";

export default function Header() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <header className="border-b border-border bg-card">
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center space-x-4">
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Code className="text-primary-foreground text-lg" />
              </div>
              <span className="text-xl font-bold text-foreground">CodeLab Pro</span>
            </div>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-6 ml-8">
            <Link href="/" className="text-sm font-medium text-foreground hover:text-primary">
              Courses
            </Link>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Challenges
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Projects
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Community
            </a>
            {(user?.role === 'instructor' || user?.role === 'admin') && (
              <Link href="/instructor" className="text-sm font-medium text-muted-foreground hover:text-primary">
                Dashboard
              </Link>
            )}
          </nav>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="Search courses, exercises..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64 pl-10 pr-4 py-2 bg-muted border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              data-testid="input-search"
            />
          </div>
          
          <Button variant="ghost" size="sm" className="p-2 hover:bg-muted rounded-lg" data-testid="button-notifications">
            <Bell className="w-4 h-4 text-muted-foreground" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-3 p-2" data-testid="button-user-menu">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user?.profileImageUrl || ""} alt={user?.firstName || "User"} />
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-sm font-medium">
                    {getInitials(user?.firstName, user?.lastName)}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden sm:block text-left">
                  <p className="text-sm font-medium" data-testid="text-user-name">
                    {user?.firstName ? `${user.firstName} ${user?.lastName || ''}` : 'User'}
                  </p>
                  <div className="flex items-center space-x-2">
                    <p className="text-xs text-muted-foreground">
                      Level {user?.level || 1}
                    </p>
                    {user?.role === 'instructor' && (
                      <Badge variant="secondary" className="text-xs">
                        Instructor
                      </Badge>
                    )}
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem data-testid="menu-profile">
                <User className="w-4 h-4 mr-2" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem data-testid="menu-settings">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </DropdownMenuItem>
              {(user?.role === 'instructor' || user?.role === 'admin') && (
                <DropdownMenuItem asChild data-testid="menu-instructor-dashboard">
                  <Link href="/instructor">
                    <Code className="w-4 h-4 mr-2" />
                    Instructor Dashboard
                  </Link>
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} data-testid="menu-logout">
                <LogOut className="w-4 h-4 mr-2" />
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
