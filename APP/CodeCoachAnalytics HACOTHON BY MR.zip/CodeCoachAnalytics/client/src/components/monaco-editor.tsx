import { useEffect, useRef } from "react";
import * as monaco from "monaco-editor";

// Configure Monaco Editor for web workers
self.MonacoEnvironment = {
  getWorkerUrl: function (moduleId, label) {
    if (label === "json") {
      return "./json.worker.bundle.js";
    }
    if (label === "css" || label === "scss" || label === "less") {
      return "./css.worker.bundle.js";
    }
    if (label === "html" || label === "handlebars" || label === "razor") {
      return "./html.worker.bundle.js";
    }
    if (label === "typescript" || label === "javascript") {
      return "./ts.worker.bundle.js";
    }
    return "./editor.worker.bundle.js";
  },
};

interface MonacoEditorProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
  theme?: string;
  height?: string;
  options?: monaco.editor.IStandaloneEditorConstructionOptions;
}

export default function MonacoEditor({
  value,
  onChange,
  language = "python",
  theme = "vs-dark",
  height = "100%",
  options = {},
}: MonacoEditorProps) {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create the editor
    const editor = monaco.editor.create(containerRef.current, {
      value,
      language,
      theme,
      automaticLayout: true,
      fontSize: 14,
      fontFamily: "var(--font-mono)",
      lineHeight: 1.6,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      wordWrap: "on",
      tabSize: 4,
      insertSpaces: true,
      renderLineHighlight: "line",
      renderWhitespace: "selection",
      folding: true,
      lineNumbers: "on",
      glyphMargin: true,
      contextmenu: true,
      mouseWheelZoom: true,
      quickSuggestions: {
        other: true,
        comments: true,
        strings: true,
      },
      suggestOnTriggerCharacters: true,
      acceptSuggestionOnEnter: "on",
      tabCompletion: "on",
      ...options,
    });

    editorRef.current = editor;

    // Set up onChange handler
    const disposable = editor.onDidChangeModelContent(() => {
      const currentValue = editor.getValue();
      onChange(currentValue);
    });

    // Configure Python language features
    if (language === "python") {
      monaco.languages.registerCompletionItemProvider("python", {
        provideCompletionItems: (model, position) => {
          const suggestions = [
            {
              label: "print",
              kind: monaco.languages.CompletionItemKind.Function,
              insertText: "print(${1:value})",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              documentation: "Print values to the console",
            },
            {
              label: "def",
              kind: monaco.languages.CompletionItemKind.Keyword,
              insertText: "def ${1:function_name}(${2:parameters}):\n\t${3:pass}",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              documentation: "Define a function",
            },
            {
              label: "if",
              kind: monaco.languages.CompletionItemKind.Keyword,
              insertText: "if ${1:condition}:\n\t${2:pass}",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              documentation: "If statement",
            },
            {
              label: "for",
              kind: monaco.languages.CompletionItemKind.Keyword,
              insertText: "for ${1:item} in ${2:iterable}:\n\t${3:pass}",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              documentation: "For loop",
            },
            {
              label: "while",
              kind: monaco.languages.CompletionItemKind.Keyword,
              insertText: "while ${1:condition}:\n\t${2:pass}",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              documentation: "While loop",
            },
          ];

          return { suggestions };
        },
      });
    }

    // Custom themes
    monaco.editor.defineTheme("codelab-dark", {
      base: "vs-dark",
      inherit: true,
      rules: [
        { token: "comment", foreground: "6A737D", fontStyle: "italic" },
        { token: "keyword", foreground: "F97316" },
        { token: "string", foreground: "10B981" },
        { token: "number", foreground: "A855F7" },
        { token: "operator", foreground: "3B82F6" },
        { token: "function", foreground: "FBBF24" },
        { token: "variable", foreground: "E5E7EB" },
      ],
      colors: {
        "editor.background": "#1C1F26",
        "editor.foreground": "#E5E7EB",
        "editor.lineHighlightBackground": "#2D3748",
        "editor.selectionBackground": "#4A5568",
        "editorCursor.foreground": "#3B82F6",
        "editorLineNumber.foreground": "#6B7280",
        "editorLineNumber.activeForeground": "#9CA3AF",
      },
    });

    if (theme === "vs-dark") {
      monaco.editor.setTheme("codelab-dark");
    }

    return () => {
      disposable.dispose();
      editor.dispose();
    };
  }, [language, theme, options]);

  // Update value when prop changes
  useEffect(() => {
    if (editorRef.current && editorRef.current.getValue() !== value) {
      editorRef.current.setValue(value);
    }
  }, [value]);

  // Update language when prop changes
  useEffect(() => {
    if (editorRef.current) {
      const model = editorRef.current.getModel();
      if (model) {
        monaco.editor.setModelLanguage(model, language);
      }
    }
  }, [language]);

  // Add error markers
  const addErrorMarkers = (errors: Array<{ line: number; column: number; message: string; severity: string }>) => {
    if (!editorRef.current) return;

    const model = editorRef.current.getModel();
    if (!model) return;

    const markers = errors.map((error) => ({
      startLineNumber: error.line,
      startColumn: error.column,
      endLineNumber: error.line,
      endColumn: error.column + 10,
      message: error.message,
      severity: error.severity === "error" 
        ? monaco.MarkerSeverity.Error 
        : error.severity === "warning"
        ? monaco.MarkerSeverity.Warning
        : monaco.MarkerSeverity.Info,
    }));

    monaco.editor.setModelMarkers(model, "errors", markers);
  };

  // Clear error markers
  const clearErrorMarkers = () => {
    if (!editorRef.current) return;
    const model = editorRef.current.getModel();
    if (!model) return;
    monaco.editor.setModelMarkers(model, "errors", []);
  };

  // Focus the editor
  const focus = () => {
    editorRef.current?.focus();
  };

  // Get current cursor position
  const getCursorPosition = () => {
    return editorRef.current?.getPosition();
  };

  // Set cursor position
  const setCursorPosition = (line: number, column: number) => {
    editorRef.current?.setPosition({ lineNumber: line, column });
  };

  // Expose methods to parent component
  useEffect(() => {
    if (editorRef.current) {
      (editorRef.current as any).addErrorMarkers = addErrorMarkers;
      (editorRef.current as any).clearErrorMarkers = clearErrorMarkers;
      (editorRef.current as any).focus = focus;
      (editorRef.current as any).getCursorPosition = getCursorPosition;
      (editorRef.current as any).setCursorPosition = setCursorPosition;
    }
  });

  return (
    <div 
      ref={containerRef} 
      className="monaco-editor-container"
      style={{ height, width: "100%" }}
      data-testid="monaco-editor"
    />
  );
}
