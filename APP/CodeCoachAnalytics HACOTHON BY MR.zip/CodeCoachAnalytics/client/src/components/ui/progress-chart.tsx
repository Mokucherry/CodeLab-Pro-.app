import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// Mock data for demonstration - in real app this would come from analytics API
const mockProgressData = [
  { date: "2025-01-01", students: 45, completion: 65, avgScore: 75 },
  { date: "2025-01-02", students: 48, completion: 68, avgScore: 78 },
  { date: "2025-01-03", students: 52, completion: 72, avgScore: 80 },
  { date: "2025-01-04", students: 55, completion: 75, avgScore: 82 },
  { date: "2025-01-05", students: 58, completion: 78, avgScore: 84 },
  { date: "2025-01-06", students: 62, completion: 80, avgScore: 85 },
  { date: "2025-01-07", students: 65, completion: 83, avgScore: 87 },
];

interface ProgressChartProps {
  data?: typeof mockProgressData;
  height?: number;
}

export default function ProgressChart({ data = mockProgressData, height = 250 }: ProgressChartProps) {
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const date = new Date(label).toLocaleDateString();
      return (
        <div className="bg-card border border-border rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium text-foreground mb-2">{date}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center space-x-2 text-xs">
              <div 
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: entry.color }}
              ></div>
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium text-foreground">
                {entry.name === "Students" ? entry.value : `${entry.value}%`}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full" style={{ height }} data-testid="progress-chart">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 20,
          }}
        >
          <CartesianGrid 
            strokeDasharray="3 3" 
            stroke="hsl(var(--border))"
            opacity={0.3}
          />
          <XAxis
            dataKey="date"
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
            tickFormatter={(date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          />
          <YAxis
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
          />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="monotone"
            dataKey="students"
            stroke="hsl(var(--primary))"
            strokeWidth={2}
            dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: "hsl(var(--primary))", strokeWidth: 2, fill: "hsl(var(--background))" }}
            name="Students"
          />
          <Line
            type="monotone"
            dataKey="completion"
            stroke="hsl(var(--chart-2))"
            strokeWidth={2}
            dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: "hsl(var(--chart-2))", strokeWidth: 2, fill: "hsl(var(--background))" }}
            name="Completion Rate"
          />
          <Line
            type="monotone"
            dataKey="avgScore"
            stroke="hsl(var(--chart-3))"
            strokeWidth={2}
            dot={{ fill: "hsl(var(--chart-3))", strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: "hsl(var(--chart-3))", strokeWidth: 2, fill: "hsl(var(--background))" }}
            name="Avg Score"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
