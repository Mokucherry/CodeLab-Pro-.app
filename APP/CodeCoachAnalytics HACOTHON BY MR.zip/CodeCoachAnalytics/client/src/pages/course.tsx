import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import RightPanel from "@/components/layout/right-panel";
import MonacoEditor from "@/components/monaco-editor";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Save, 
  Bug, 
  Settings,
  Plus,
  Circle,
  Check
} from "lucide-react";
import type { Course, Lesson, Exercise, UserProgress } from "@shared/schema";

export default function CoursePage() {
  const { id } = useParams();
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  
  const [currentExerciseId, setCurrentExerciseId] = useState<string>("");
  const [code, setCode] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"output" | "hints" | "tests" | "debug">("output");
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: ["/api/courses", id],
    retry: false,
  });

  const { data: lessons, isLoading: lessonsLoading } = useQuery({
    queryKey: ["/api/courses", id, "lessons"],
    retry: false,
    enabled: !!id,
  });

  const { data: exercises, isLoading: exercisesLoading } = useQuery({
    queryKey: ["/api/lessons", lessons?.[0]?.id, "exercises"],
    retry: false,
    enabled: !!lessons?.[0]?.id,
  });

  const { data: currentExercise } = useQuery({
    queryKey: ["/api/exercises", currentExerciseId],
    retry: false,
    enabled: !!currentExerciseId,
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/user/progress", currentExerciseId],
    retry: false,
    enabled: !!currentExerciseId,
  });

  // Set initial exercise and code when data loads
  useEffect(() => {
    if (exercises?.length > 0 && !currentExerciseId) {
      const firstExercise = exercises[0];
      setCurrentExerciseId(firstExercise.id);
      setCode(firstExercise.starterCode || "# Write your code here\n");
    }
  }, [exercises, currentExerciseId]);

  // Update code when exercise changes
  useEffect(() => {
    if (currentExercise) {
      if (userProgress?.currentCode) {
        setCode(userProgress.currentCode);
      } else {
        setCode(currentExercise.starterCode || "# Write your code here\n");
      }
    }
  }, [currentExercise, userProgress]);

  const executeMutation = useMutation({
    mutationFn: async (data: { code: string; language: string; exerciseId: string }) => {
      const response = await apiRequest("POST", "/api/code/execute", data);
      return await response.json();
    },
    onSuccess: (data) => {
      setExecutionResult(data);
      setIsExecuting(false);
      queryClient.invalidateQueries({ queryKey: ["/api/user/progress", currentExerciseId] });
    },
    onError: (error) => {
      setIsExecuting(false);
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Execution Error",
        description: "Failed to execute code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRunCode = () => {
    if (!currentExercise) return;
    
    setIsExecuting(true);
    setActiveTab("output");
    
    executeMutation.mutate({
      code,
      language: course?.language || "python",
      exerciseId: currentExerciseId,
    });
  };

  const handleExerciseSelect = (exerciseId: string) => {
    setCurrentExerciseId(exerciseId);
    setExecutionResult(null);
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (courseLoading || lessonsLoading || exercisesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="flex h-[calc(100vh-4rem)]">
          <div className="w-80 bg-card border-r border-border p-4 space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="loading-skeleton h-20"></div>
            ))}
          </div>
          <div className="flex-1 loading-skeleton"></div>
          <div className="w-96 bg-card border-l border-border p-4 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="loading-skeleton h-16"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="flex h-[calc(100vh-4rem)]">
        <Sidebar 
          course={course}
          lessons={lessons || []}
          exercises={exercises || []}
          currentExerciseId={currentExerciseId}
          onExerciseSelect={handleExerciseSelect}
        />

        {/* Main Editor Area */}
        <main className="flex-1 flex flex-col">
          {/* Editor Toolbar */}
          <div className="h-12 bg-card border-b border-border flex items-center justify-between px-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="bg-muted px-3 py-1 rounded text-sm font-medium">
                  main.py
                </div>
                <button className="text-muted-foreground hover:text-foreground text-sm">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button 
                  onClick={handleRunCode}
                  disabled={isExecuting || !currentExercise}
                  className="bg-primary text-primary-foreground px-4 py-1.5 rounded text-sm font-medium hover:bg-primary/90 flex items-center space-x-2"
                  data-testid="button-run-code"
                >
                  <Play className="w-4 h-4" />
                  <span>{isExecuting ? "Running..." : "Run Code"}</span>
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  className="flex items-center space-x-2"
                  data-testid="button-debug"
                >
                  <Bug className="w-4 h-4" />
                  <span>Debug</span>
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  data-testid="button-save"
                >
                  <Save className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${
                  executionResult?.execution?.success === false 
                    ? "bg-red-500" 
                    : executionResult?.execution?.success 
                    ? "bg-green-500" 
                    : "bg-gray-400"
                }`}></div>
                <span className="text-sm text-muted-foreground">
                  {executionResult?.execution?.success === false 
                    ? "Errors found" 
                    : executionResult?.execution?.success 
                    ? "All tests passing" 
                    : "Ready to run"}
                </span>
              </div>
              <button className="text-muted-foreground hover:text-foreground">
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {/* Monaco Editor */}
          <div className="flex-1">
            <MonacoEditor
              value={code}
              onChange={setCode}
              language="python"
              theme="vs-dark"
            />
          </div>
        </main>

        <RightPanel 
          activeTab={activeTab}
          onTabChange={setActiveTab}
          executionResult={executionResult}
          currentExercise={currentExercise}
          isExecuting={isExecuting}
        />
      </div>

      {/* Bottom Collaboration Panel */}
      <div className="bg-card border-t border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Circle className="w-4 h-4 text-green-500 fill-current" />
              <span className="text-sm text-muted-foreground">2 peers online</span>
            </div>
            <Button size="sm" className="bg-primary text-primary-foreground" data-testid="button-pair-session">
              Start Pair Session
            </Button>
            <Button size="sm" variant="outline" data-testid="button-ask-help">
              Ask for Help
            </Button>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-medium">5</span>
              </div>
              <span className="text-sm text-muted-foreground">Streak</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-amber-500" />
              <span className="text-sm text-muted-foreground">1,250 XP</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
