import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ProgressChart from "@/components/ui/progress-chart";
import { 
  Users, 
  BookOpen, 
  TrendingUp, 
  AlertTriangle,
  Plus,
  Eye,
  Edit,
  BarChart3
} from "lucide-react";

export default function InstructorDashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated or not an instructor
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (!isLoading && user && user.role !== 'instructor' && user.role !== 'admin') {
      toast({
        title: "Access Denied",
        description: "You need instructor privileges to access this page.",
        variant: "destructive",
      });
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: courses, isLoading: coursesLoading } = useQuery({
    queryKey: ["/api/instructor/courses"],
    retry: false,
    enabled: !!user && (user.role === 'instructor' || user.role === 'admin'),
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (user?.role !== 'instructor' && user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-6 py-8">
          <Card>
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-foreground mb-2">Access Denied</h2>
              <p className="text-muted-foreground">
                You need instructor privileges to access this dashboard.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Mock data for demonstration
  const mockStats = {
    totalStudents: 142,
    activeCourses: courses?.length || 0,
    completionRate: 85,
    avgSessionTime: 45
  };

  const mockRecentActivity = [
    { student: "Alice Johnson", course: "Python Fundamentals", action: "Completed Exercise 5", time: "2 hours ago" },
    { student: "Bob Smith", course: "JavaScript Basics", action: "Requested help", time: "3 hours ago" },
    { student: "Carol Davis", course: "Python Fundamentals", action: "Started Lesson 3", time: "5 hours ago" },
  ];

  const mockErrorPatterns = [
    { error: "IndexError: list index out of range", count: 23, course: "Python Fundamentals" },
    { error: "SyntaxError: unexpected token", count: 18, course: "JavaScript Basics" },
    { error: "TypeError: Cannot read property", count: 15, course: "JavaScript Basics" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-dashboard-title">
              Instructor Dashboard
            </h1>
            <p className="text-muted-foreground">
              Monitor student progress and manage your courses
            </p>
          </div>
          <Button className="bg-primary hover:bg-primary/90" data-testid="button-create-course">
            <Plus className="w-4 h-4 mr-2" />
            Create Course
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Students</p>
                  <p className="text-2xl font-bold" data-testid="text-total-students">
                    {mockStats.totalStudents}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-4 h-4 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Courses</p>
                  <p className="text-2xl font-bold" data-testid="text-active-courses">
                    {mockStats.activeCourses}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Completion Rate</p>
                  <p className="text-2xl font-bold" data-testid="text-completion-rate">
                    {mockStats.completionRate}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg Session</p>
                  <p className="text-2xl font-bold" data-testid="text-avg-session">
                    {mockStats.avgSessionTime}m
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Courses */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Courses</CardTitle>
              </CardHeader>
              <CardContent>
                {coursesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="loading-skeleton h-20"></div>
                    ))}
                  </div>
                ) : courses?.length === 0 ? (
                  <div className="text-center py-8">
                    <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">No courses yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Create your first course to start teaching students.
                    </p>
                    <Button data-testid="button-create-first-course">
                      Create Your First Course
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {courses?.map((course: any) => (
                      <div key={course.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="font-semibold text-foreground">{course.title}</h3>
                              <Badge variant={course.isPublished ? "default" : "secondary"}>
                                {course.isPublished ? "Published" : "Draft"}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">
                              {course.description}
                            </p>
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                              <span>{course.language}</span>
                              <span>•</span>
                              <span>{course.difficulty}</span>
                              <span>•</span>
                              <span>{course.estimatedHours}h</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline" data-testid={`button-view-${course.id}`}>
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                            <Button size="sm" variant="outline" data-testid={`button-edit-${course.id}`}>
                              <Edit className="w-4 h-4 mr-1" />
                              Edit
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Progress Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Student Progress Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ProgressChart />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockRecentActivity.map((activity, index) => (
                    <div key={index} className="border-l-2 border-primary/20 pl-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {activity.student}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {activity.course}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {activity.action}
                          </p>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {activity.time}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Common Error Patterns */}
            <Card>
              <CardHeader>
                <CardTitle>Common Error Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockErrorPatterns.map((error, index) => (
                    <div key={index} className="bg-red-50 dark:bg-red-900/20 rounded-lg p-3">
                      <div className="flex items-start justify-between mb-1">
                        <p className="text-sm font-medium text-red-800 dark:text-red-200">
                          {error.error}
                        </p>
                        <Badge variant="destructive" className="text-xs">
                          {error.count}
                        </Badge>
                      </div>
                      <p className="text-xs text-red-600 dark:text-red-400">
                        {error.course}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardContent className="p-6">
                <div className="space-y-3">
                  <Button className="w-full justify-start" variant="ghost" data-testid="button-view-analytics">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                  <Button className="w-full justify-start" variant="ghost" data-testid="button-export-reports">
                    Export Reports
                  </Button>
                  <Button className="w-full justify-start" variant="ghost" data-testid="button-manage-students">
                    Manage Students
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
