import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/layout/header";
import { 
  BookOpen, 
  Code, 
  Trophy, 
  Clock, 
  Target,
  TrendingUp,
  Users,
  PlayCircle
} from "lucide-react";
import { Link } from "wouter";
import type { Course, Enrollment } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: courses, isLoading: coursesLoading } = useQuery({
    queryKey: ["/api/courses"],
    retry: false,
  });

  const { data: enrollments, isLoading: enrollmentsLoading } = useQuery({
    queryKey: ["/api/user/enrollments"],
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const enrolledCourseIds = enrollments?.map((e: Enrollment) => e.courseId) || [];
  const enrolledCourses = courses?.filter((c: Course) => enrolledCourseIds.includes(c.id)) || [];
  const availableCourses = courses?.filter((c: Course) => !enrolledCourseIds.includes(c.id)) || [];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-welcome">
            Welcome back, {user?.firstName || 'Student'}! 👋
          </h1>
          <p className="text-muted-foreground">
            Continue your coding journey and master new skills today.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Courses</p>
                  <p className="text-2xl font-bold" data-testid="text-courses-count">
                    {enrolledCourses.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <Trophy className="w-4 h-4 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">XP Points</p>
                  <p className="text-2xl font-bold" data-testid="text-xp-points">
                    {user?.xp || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                  <Target className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Streak</p>
                  <p className="text-2xl font-bold" data-testid="text-streak">
                    {user?.streak || 0} days
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Level</p>
                  <p className="text-2xl font-bold" data-testid="text-level">
                    {user?.level || 1}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Courses */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-foreground">My Courses</h2>
              <Button variant="outline" size="sm" data-testid="button-view-all">
                View All
              </Button>
            </div>

            {enrollmentsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="loading-skeleton h-32"></div>
                ))}
              </div>
            ) : enrolledCourses.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">No courses yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start your learning journey by enrolling in a course below.
                  </p>
                  <Button data-testid="button-browse-courses">
                    Browse Courses
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {enrolledCourses.map((course: Course) => (
                  <Card key={course.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="text-lg font-semibold text-foreground">
                              {course.title}
                            </h3>
                            <Badge variant="secondary" data-testid={`badge-difficulty-${course.id}`}>
                              {course.difficulty}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground text-sm mb-3">
                            {course.description}
                          </p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <div className="flex items-center space-x-1">
                              <Code className="w-4 h-4" />
                              <span>{course.language}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>{course.estimatedHours}h</span>
                            </div>
                          </div>
                        </div>
                        <Button asChild data-testid={`button-continue-${course.id}`}>
                          <Link href={`/course/${course.id}`}>
                            <PlayCircle className="w-4 h-4 mr-2" />
                            Continue
                          </Link>
                        </Button>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium" data-testid={`text-progress-${course.id}`}>
                            {/* This would come from enrollment progress */}
                            0%
                          </span>
                        </div>
                        <Progress value={0} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" variant="ghost" data-testid="button-practice-session">
                  <Code className="w-4 h-4 mr-2" />
                  Start Practice Session
                </Button>
                <Button className="w-full justify-start" variant="ghost" data-testid="button-join-challenge">
                  <Trophy className="w-4 h-4 mr-2" />
                  Join Coding Challenge
                </Button>
                <Button className="w-full justify-start" variant="ghost" data-testid="button-pair-programming">
                  <Users className="w-4 h-4 mr-2" />
                  Pair Programming
                </Button>
              </CardContent>
            </Card>

            {/* Available Courses */}
            <Card>
              <CardHeader>
                <CardTitle>Explore New Courses</CardTitle>
              </CardHeader>
              <CardContent>
                {coursesLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="loading-skeleton h-16"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {availableCourses.slice(0, 3).map((course: Course) => (
                      <div key={course.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium text-sm">{course.title}</h4>
                            <p className="text-xs text-muted-foreground">
                              {course.language} • {course.difficulty}
                            </p>
                          </div>
                          <Button size="sm" variant="outline" data-testid={`button-enroll-${course.id}`}>
                            Enroll
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Learning Streak */}
            <Card>
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl">🔥</span>
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">
                    {user?.streak || 0} Day Streak!
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Keep coding daily to maintain your streak
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
