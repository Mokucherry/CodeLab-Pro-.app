import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface CodeAnalysisResult {
  hasErrors: boolean;
  errors: {
    line: number;
    column: number;
    message: string;
    severity: "error" | "warning" | "info";
    errorType: string;
    suggestion?: string;
  }[];
  suggestions: {
    type: "fix" | "improvement" | "optimization";
    message: string;
    code?: string;
    explanation?: string;
  }[];
  complexity: {
    score: number;
    feedback: string;
  };
  testResults?: {
    passed: number;
    failed: number;
    details: {
      name: string;
      passed: boolean;
      expected?: any;
      actual?: any;
      error?: string;
    }[];
  };
}

export interface HintRequest {
  code: string;
  exercise: {
    title: string;
    description: string;
    starterCode: string;
  };
  previousHints: string[];
  language: string;
}

export interface HintResponse {
  hint: string;
  hintType: "gentle" | "progressive" | "explicit";
  codeExample?: string;
  nextStep?: string;
}

export class CodeAnalysisService {
  async analyzeCode(
    code: string,
    language: string,
    testCases?: any[],
    exerciseContext?: { title: string; description: string }
  ): Promise<CodeAnalysisResult> {
    try {
      const prompt = `
Analyze this ${language} code for errors, improvements, and provide feedback:

Code:
\`\`\`${language}
${code}
\`\`\`

${exerciseContext ? `Exercise Context: ${exerciseContext.title} - ${exerciseContext.description}` : ''}

${testCases ? `Test Cases: ${JSON.stringify(testCases)}` : ''}

Please provide a comprehensive analysis including:
1. Syntax and runtime errors with line numbers
2. Code quality suggestions
3. Performance optimizations
4. Best practice recommendations
5. Complexity assessment (1-10 scale)

Respond with JSON in this format:
{
  "hasErrors": boolean,
  "errors": [{"line": number, "column": number, "message": string, "severity": "error|warning|info", "errorType": string, "suggestion": string}],
  "suggestions": [{"type": "fix|improvement|optimization", "message": string, "code": string, "explanation": string}],
  "complexity": {"score": number, "feedback": string}
}
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are an expert programming instructor and code analysis tool. Provide detailed, educational feedback that helps students learn."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
      });

      const analysis = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        hasErrors: analysis.hasErrors || false,
        errors: analysis.errors || [],
        suggestions: analysis.suggestions || [],
        complexity: analysis.complexity || { score: 5, feedback: "Moderate complexity" }
      };
    } catch (error) {
      console.error("Code analysis error:", error);
      return {
        hasErrors: true,
        errors: [{
          line: 1,
          column: 1,
          message: "Unable to analyze code at this time",
          severity: "error",
          errorType: "analysis_error"
        }],
        suggestions: [],
        complexity: { score: 0, feedback: "Analysis unavailable" }
      };
    }
  }

  async generateHint(request: HintRequest): Promise<HintResponse> {
    try {
      const hintLevel = request.previousHints.length;
      const hintType = hintLevel === 0 ? "gentle" : hintLevel < 2 ? "progressive" : "explicit";

      const prompt = `
You are helping a student with a coding exercise. Generate an appropriate hint based on their current progress.

Exercise: ${request.exercise.title}
Description: ${request.exercise.description}

Starter Code:
\`\`\`${request.language}
${request.exercise.starterCode}
\`\`\`

Student's Current Code:
\`\`\`${request.language}
${request.code}
\`\`\`

Previous Hints Given: ${request.previousHints.length}
${request.previousHints.map((hint, i) => `${i + 1}. ${hint}`).join('\n')}

Hint Level: ${hintType}
- gentle: Give a conceptual nudge without showing code
- progressive: Provide more specific guidance and direction
- explicit: Show specific code examples or solutions

Respond with JSON:
{
  "hint": "Your educational hint here",
  "hintType": "${hintType}",
  "codeExample": "optional code snippet if needed",
  "nextStep": "what the student should try next"
}
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a patient, encouraging programming tutor. Your hints should guide students to discover solutions themselves rather than giving direct answers."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
      });

      const hintData = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        hint: hintData.hint || "Try reviewing the exercise requirements and think about the problem step by step.",
        hintType: hintType,
        codeExample: hintData.codeExample,
        nextStep: hintData.nextStep
      };
    } catch (error) {
      console.error("Hint generation error:", error);
      return {
        hint: "Having trouble generating a hint right now. Try reviewing the exercise description and breaking the problem into smaller steps.",
        hintType: "gentle"
      };
    }
  }

  async debugCode(
    code: string,
    error: string,
    language: string,
    exerciseContext?: { title: string; description: string }
  ): Promise<{ explanation: string; suggestedFix: string; codeExample?: string }> {
    try {
      const prompt = `
Help debug this ${language} code that's producing an error:

Code:
\`\`\`${language}
${code}
\`\`\`

Error: ${error}

${exerciseContext ? `Exercise Context: ${exerciseContext.title} - ${exerciseContext.description}` : ''}

Provide a clear explanation of what went wrong and suggest a fix. Focus on teaching the underlying concept.

Respond with JSON:
{
  "explanation": "Clear explanation of what caused the error",
  "suggestedFix": "Description of how to fix it",
  "codeExample": "Corrected code example if helpful"
}
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a debugging expert and programming tutor. Explain errors in a way that helps students understand and learn from their mistakes."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4,
      });

      const debugData = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        explanation: debugData.explanation || "Unable to analyze this error right now.",
        suggestedFix: debugData.suggestedFix || "Please review your code and try again.",
        codeExample: debugData.codeExample
      };
    } catch (error) {
      console.error("Debug generation error:", error);
      return {
        explanation: "Unable to analyze this error at the moment.",
        suggestedFix: "Please check your syntax and logic, then try running the code again."
      };
    }
  }
}

export const codeAnalysisService = new CodeAnalysisService();
