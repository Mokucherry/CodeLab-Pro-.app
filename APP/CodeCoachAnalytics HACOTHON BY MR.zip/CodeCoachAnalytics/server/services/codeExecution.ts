// Code execution service - currently stubbed for security and complexity reasons
// In production, this would use containerized sandboxes (Docker/Kubernetes)

export interface ExecutionResult {
  success: boolean;
  output: string;
  errors: string[];
  executionTime: number;
  memoryUsed: number;
  testResults?: {
    passed: number;
    failed: number;
    total: number;
    details: TestResult[];
  };
}

export interface TestResult {
  name: string;
  passed: boolean;
  expected?: any;
  actual?: any;
  error?: string;
}

export interface ExecutionRequest {
  code: string;
  language: string;
  testCases?: any[];
  timeLimit?: number; // in seconds
  memoryLimit?: number; // in MB
}

export class CodeExecutionService {
  async executeCode(request: ExecutionRequest): Promise<ExecutionResult> {
    // For now, we'll simulate code execution
    // In production, this would:
    // 1. Create a secure container
    // 2. Copy code into container
    // 3. Execute with resource limits
    // 4. Capture output, errors, and metrics
    // 5. Run test cases if provided
    // 6. Clean up container
    
    const { code, language, testCases } = request;
    
    // Simulate execution delay
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
    
    // Basic syntax checking simulation
    const hasBasicErrors = this.checkBasicSyntax(code, language);
    
    if (hasBasicErrors.length > 0) {
      return {
        success: false,
        output: "",
        errors: hasBasicErrors,
        executionTime: 0.1,
        memoryUsed: 0,
      };
    }
    
    // Simulate successful execution
    const simulatedOutput = this.simulateOutput(code, language);
    const testResults = testCases ? this.simulateTestExecution(code, testCases) : undefined;
    
    return {
      success: true,
      output: simulatedOutput,
      errors: [],
      executionTime: 0.5 + Math.random() * 1.5,
      memoryUsed: 10 + Math.random() * 50,
      testResults,
    };
  }
  
  private checkBasicSyntax(code: string, language: string): string[] {
    const errors: string[] = [];
    
    if (language === "python") {
      // Basic Python syntax checks
      const lines = code.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.endsWith(':') && i + 1 < lines.length) {
          const nextLine = lines[i + 1];
          if (nextLine.trim() && !nextLine.startsWith(' ') && !nextLine.startsWith('\t')) {
            errors.push(`IndentationError: expected an indented block after line ${i + 1}`);
          }
        }
        
        // Check for common syntax errors
        const openParens = (line.match(/\(/g) || []).length;
        const closeParens = (line.match(/\)/g) || []).length;
        if (openParens !== closeParens) {
          errors.push(`SyntaxError: unmatched parentheses on line ${i + 1}`);
        }
      }
    } else if (language === "javascript") {
      // Basic JavaScript syntax checks
      const openBraces = (code.match(/\{/g) || []).length;
      const closeBraces = (code.match(/\}/g) || []).length;
      if (openBraces !== closeBraces) {
        errors.push("SyntaxError: Unexpected end of input - missing closing brace");
      }
      
      const openParens = (code.match(/\(/g) || []).length;
      const closeParens = (code.match(/\)/g) || []).length;
      if (openParens !== closeParens) {
        errors.push("SyntaxError: missing ) after argument list");
      }
    }
    
    return errors;
  }
  
  private simulateOutput(code: string, language: string): string {
    // Simulate output based on code content
    if (language === "python") {
      if (code.includes("print(")) {
        const printMatches = code.match(/print\(([^)]+)\)/g);
        if (printMatches) {
          return printMatches.map(match => {
            const content = match.slice(6, -1); // Remove "print(" and ")"
            // Simple evaluation for demo
            if (content.includes('"') || content.includes("'")) {
              return content.replace(/['"]/g, '');
            }
            return content;
          }).join('\n');
        }
      }
      
      if (code.includes("def ") && code.includes("return")) {
        return "Function defined successfully";
      }
    } else if (language === "javascript") {
      if (code.includes("console.log")) {
        const logMatches = code.match(/console\.log\(([^)]+)\)/g);
        if (logMatches) {
          return logMatches.map(match => {
            const content = match.slice(12, -1); // Remove "console.log(" and ")"
            if (content.includes('"') || content.includes("'")) {
              return content.replace(/['"]/g, '');
            }
            return content;
          }).join('\n');
        }
      }
    }
    
    return "Code executed successfully";
  }
  
  private simulateTestExecution(code: string, testCases: any[]): {
    passed: number;
    failed: number;
    total: number;
    details: TestResult[];
  } {
    // Simulate test execution
    const details: TestResult[] = testCases.map((testCase, index) => {
      // Randomly pass/fail tests for simulation
      const passed = Math.random() > 0.3; // 70% pass rate
      
      return {
        name: testCase.name || `Test ${index + 1}`,
        passed,
        expected: testCase.expected,
        actual: passed ? testCase.expected : "Different output",
        error: passed ? undefined : "AssertionError: Test failed"
      };
    });
    
    const passed = details.filter(d => d.passed).length;
    const failed = details.length - passed;
    
    return {
      passed,
      failed,
      total: details.length,
      details
    };
  }
}

export const codeExecutionService = new CodeExecutionService();
