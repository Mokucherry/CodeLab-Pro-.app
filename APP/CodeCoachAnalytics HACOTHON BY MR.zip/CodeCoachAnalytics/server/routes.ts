import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { codeAnalysisService } from "./services/codeAnalysis";
import { codeExecutionService } from "./services/codeExecution";
import { insertSubmissionSchema, insertProgressSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const course = await storage.getCourse(req.params.id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.get('/api/courses/:id/lessons', async (req, res) => {
    try {
      const lessons = await storage.getLessonsByCourse(req.params.id);
      res.json(lessons);
    } catch (error) {
      console.error("Error fetching lessons:", error);
      res.status(500).json({ message: "Failed to fetch lessons" });
    }
  });

  app.post('/api/courses/:id/enroll', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const courseId = req.params.id;
      
      const enrollment = await storage.enrollUser(userId, courseId);
      res.json(enrollment);
    } catch (error) {
      console.error("Error enrolling user:", error);
      res.status(500).json({ message: "Failed to enroll in course" });
    }
  });

  // Lesson routes
  app.get('/api/lessons/:id', async (req, res) => {
    try {
      const lesson = await storage.getLesson(req.params.id);
      if (!lesson) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      res.json(lesson);
    } catch (error) {
      console.error("Error fetching lesson:", error);
      res.status(500).json({ message: "Failed to fetch lesson" });
    }
  });

  app.get('/api/lessons/:id/exercises', async (req, res) => {
    try {
      const exercises = await storage.getExercisesByLesson(req.params.id);
      res.json(exercises);
    } catch (error) {
      console.error("Error fetching exercises:", error);
      res.status(500).json({ message: "Failed to fetch exercises" });
    }
  });

  // Exercise routes
  app.get('/api/exercises/:id', async (req, res) => {
    try {
      const exercise = await storage.getExercise(req.params.id);
      if (!exercise) {
        return res.status(404).json({ message: "Exercise not found" });
      }
      res.json(exercise);
    } catch (error) {
      console.error("Error fetching exercise:", error);
      res.status(500).json({ message: "Failed to fetch exercise" });
    }
  });

  app.get('/api/exercises/:id/hints', async (req, res) => {
    try {
      const hints = await storage.getHintsByExercise(req.params.id);
      res.json(hints);
    } catch (error) {
      console.error("Error fetching hints:", error);
      res.status(500).json({ message: "Failed to fetch hints" });
    }
  });

  // Code execution and analysis routes
  app.post('/api/code/execute', isAuthenticated, async (req: any, res) => {
    try {
      const { code, language, exerciseId, testCases } = req.body;
      
      // Execute code
      const executionResult = await codeExecutionService.executeCode({
        code,
        language,
        testCases,
        timeLimit: 30,
        memoryLimit: 128
      });

      // Analyze code
      const exercise = exerciseId ? await storage.getExercise(exerciseId) : undefined;
      const analysisResult = await codeAnalysisService.analyzeCode(
        code, 
        language, 
        testCases,
        exercise ? { title: exercise.title, description: exercise.description } : undefined
      );

      // Save submission
      if (exerciseId) {
        const userId = req.user.claims.sub;
        await storage.createSubmission({
          userId,
          exerciseId,
          code,
          language,
          output: executionResult.output,
          errors: executionResult.errors,
          testResults: executionResult.testResults,
          score: executionResult.testResults ? 
            (executionResult.testResults.passed / executionResult.testResults.total) * 100 : 
            undefined,
          aiAnalysis: analysisResult
        });

        // Update progress
        await storage.updateUserProgress(userId, exerciseId, {
          currentCode: code,
          attempts: (await storage.getUserProgress(userId, exerciseId))?.attempts || 0 + 1,
          status: executionResult.success && !analysisResult.hasErrors ? 'completed' : 'in_progress'
        });
      }

      res.json({
        execution: executionResult,
        analysis: analysisResult
      });
    } catch (error) {
      console.error("Error executing code:", error);
      res.status(500).json({ message: "Failed to execute code" });
    }
  });

  app.post('/api/code/analyze', isAuthenticated, async (req, res) => {
    try {
      const { code, language, exerciseId } = req.body;
      
      const exercise = exerciseId ? await storage.getExercise(exerciseId) : undefined;
      const result = await codeAnalysisService.analyzeCode(
        code, 
        language, 
        undefined,
        exercise ? { title: exercise.title, description: exercise.description } : undefined
      );
      
      res.json(result);
    } catch (error) {
      console.error("Error analyzing code:", error);
      res.status(500).json({ message: "Failed to analyze code" });
    }
  });

  app.post('/api/hints/generate', isAuthenticated, async (req: any, res) => {
    try {
      const { code, exerciseId, previousHints } = req.body;
      
      const exercise = await storage.getExercise(exerciseId);
      if (!exercise) {
        return res.status(404).json({ message: "Exercise not found" });
      }

      const hint = await codeAnalysisService.generateHint({
        code,
        exercise: {
          title: exercise.title,
          description: exercise.description,
          starterCode: exercise.starterCode || ""
        },
        previousHints: previousHints || [],
        language: "python" // Default, should be dynamic based on exercise
      });

      // Update user progress to track hint usage
      const userId = req.user.claims.sub;
      const currentProgress = await storage.getUserProgress(userId, exerciseId);
      await storage.updateUserProgress(userId, exerciseId, {
        hintsUsed: (currentProgress?.hintsUsed || 0) + 1
      });

      res.json(hint);
    } catch (error) {
      console.error("Error generating hint:", error);
      res.status(500).json({ message: "Failed to generate hint" });
    }
  });

  app.post('/api/debug', isAuthenticated, async (req, res) => {
    try {
      const { code, error, language, exerciseId } = req.body;
      
      const exercise = exerciseId ? await storage.getExercise(exerciseId) : undefined;
      const result = await codeAnalysisService.debugCode(
        code,
        error,
        language,
        exercise ? { title: exercise.title, description: exercise.description } : undefined
      );
      
      res.json(result);
    } catch (error) {
      console.error("Error debugging code:", error);
      res.status(500).json({ message: "Failed to debug code" });
    }
  });

  // User progress and enrollment routes
  app.get('/api/user/enrollments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const enrollments = await storage.getUserEnrollments(userId);
      res.json(enrollments);
    } catch (error) {
      console.error("Error fetching user enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  app.get('/api/user/progress/:exerciseId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const progress = await storage.getUserProgress(userId, req.params.exerciseId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching user progress:", error);
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  app.get('/api/user/submissions/:exerciseId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const submissions = await storage.getUserSubmissions(userId, req.params.exerciseId);
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching user submissions:", error);
      res.status(500).json({ message: "Failed to fetch submissions" });
    }
  });

  // Instructor routes
  app.get('/api/instructor/courses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'instructor' && user?.role !== 'admin') {
        return res.status(403).json({ message: "Access denied. Instructor role required." });
      }
      
      const courses = await storage.getInstructorCourses(userId);
      res.json(courses);
    } catch (error) {
      console.error("Error fetching instructor courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
