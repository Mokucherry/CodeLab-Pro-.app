import {
  users,
  courses,
  lessons,
  exercises,
  enrollments,
  userProgress,
  codeSubmissions,
  hints,
  type User,
  type UpsertUser,
  type Course,
  type InsertCourse,
  type Lesson,
  type InsertLesson,
  type Exercise,
  type InsertExercise,
  type Enrollment,
  type UserProgress,
  type InsertProgress,
  type CodeSubmission,
  type InsertSubmission,
  type Hint,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, course: Partial<InsertCourse>): Promise<Course>;
  getInstructorCourses(instructorId: string): Promise<Course[]>;
  
  // Lesson operations
  getLessonsByCourse(courseId: string): Promise<Lesson[]>;
  getLesson(id: string): Promise<Lesson | undefined>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  
  // Exercise operations
  getExercisesByLesson(lessonId: string): Promise<Exercise[]>;
  getExercise(id: string): Promise<Exercise | undefined>;
  createExercise(exercise: InsertExercise): Promise<Exercise>;
  
  // Enrollment operations
  enrollUser(userId: string, courseId: string): Promise<Enrollment>;
  getUserEnrollments(userId: string): Promise<Enrollment[]>;
  
  // Progress operations
  getUserProgress(userId: string, exerciseId: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, exerciseId: string, progress: Partial<InsertProgress>): Promise<UserProgress>;
  
  // Submission operations
  createSubmission(submission: InsertSubmission): Promise<CodeSubmission>;
  getUserSubmissions(userId: string, exerciseId: string): Promise<CodeSubmission[]>;
  
  // Hint operations
  getHintsByExercise(exerciseId: string): Promise<Hint[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Course operations
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.isPublished, true));
  }

  async getCourse(id: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  async updateCourse(id: string, course: Partial<InsertCourse>): Promise<Course> {
    const [updatedCourse] = await db
      .update(courses)
      .set({ ...course, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return updatedCourse;
  }

  async getInstructorCourses(instructorId: string): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.instructorId, instructorId));
  }

  // Lesson operations
  async getLessonsByCourse(courseId: string): Promise<Lesson[]> {
    return await db
      .select()
      .from(lessons)
      .where(eq(lessons.courseId, courseId))
      .orderBy(asc(lessons.orderIndex));
  }

  async getLesson(id: string): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson;
  }

  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    const [newLesson] = await db.insert(lessons).values(lesson).returning();
    return newLesson;
  }

  // Exercise operations
  async getExercisesByLesson(lessonId: string): Promise<Exercise[]> {
    return await db
      .select()
      .from(exercises)
      .where(eq(exercises.lessonId, lessonId))
      .orderBy(asc(exercises.orderIndex));
  }

  async getExercise(id: string): Promise<Exercise | undefined> {
    const [exercise] = await db.select().from(exercises).where(eq(exercises.id, id));
    return exercise;
  }

  async createExercise(exercise: InsertExercise): Promise<Exercise> {
    const [newExercise] = await db.insert(exercises).values(exercise).returning();
    return newExercise;
  }

  // Enrollment operations
  async enrollUser(userId: string, courseId: string): Promise<Enrollment> {
    const [enrollment] = await db
      .insert(enrollments)
      .values({ userId, courseId })
      .returning();
    return enrollment;
  }

  async getUserEnrollments(userId: string): Promise<Enrollment[]> {
    return await db.select().from(enrollments).where(eq(enrollments.userId, userId));
  }

  // Progress operations
  async getUserProgress(userId: string, exerciseId: string): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.exerciseId, exerciseId)));
    return progress;
  }

  async updateUserProgress(userId: string, exerciseId: string, progress: Partial<InsertProgress>): Promise<UserProgress> {
    const existing = await this.getUserProgress(userId, exerciseId);
    
    if (existing) {
      const [updated] = await db
        .update(userProgress)
        .set({ ...progress, updatedAt: new Date() })
        .where(and(eq(userProgress.userId, userId), eq(userProgress.exerciseId, exerciseId)))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(userProgress)
        .values({ userId, exerciseId, ...progress })
        .returning();
      return created;
    }
  }

  // Submission operations
  async createSubmission(submission: InsertSubmission): Promise<CodeSubmission> {
    const [newSubmission] = await db.insert(codeSubmissions).values(submission).returning();
    return newSubmission;
  }

  async getUserSubmissions(userId: string, exerciseId: string): Promise<CodeSubmission[]> {
    return await db
      .select()
      .from(codeSubmissions)
      .where(and(eq(codeSubmissions.userId, userId), eq(codeSubmissions.exerciseId, exerciseId)))
      .orderBy(desc(codeSubmissions.submittedAt));
  }

  // Hint operations
  async getHintsByExercise(exerciseId: string): Promise<Hint[]> {
    return await db
      .select()
      .from(hints)
      .where(eq(hints.exerciseId, exerciseId))
      .orderBy(asc(hints.orderIndex));
  }
}

export const storage = new DatabaseStorage();
